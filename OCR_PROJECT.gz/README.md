Project_OCR
Overview
Optical Character Recognition (OCR) service built with Flask, Celery, and Redis. It allows users to submit images, processes them using Tesseract OCR, and retrieves the extracted text. This project includes a simple web frontend and a backend service that handles OCR tasks asynchronously.

Features
OCR Service: Extracts text from images using Tesseract OCR.
Frontend: Simple interface for submitting images.
Asynchronous Processing: Uses Celery with Redis for background task processing.


API Endpoints:
POST /image-sync: Processes the image synchronously.
POST /image: Submits the image for asynchronous processing.
GET /image/<task_id>: Retrieves the status and result of the asynchronous OCR task.
Requirements
Docker
Docker Compose
Python 3.x
Tesseract OCR


API Usage
You can use tools like Postman to interact with the API endpoints. The frontend of the application supports image conversion to Base64, allowing for easy testing of image uploads and OCR processing.

Image Conversion
To manually test the API, you can convert images to Base64 format using the provided base_64.py script or through the frontend interface.

Using base_64.py Script
Update the Script: Open the base_64.py file and set the image file path in the IMAGE_PATH variable.

Run the Script: Execute the base_64.py script to convert your image to Base64 format.

python base_64.py
Script Output: The script will output the Base64 encoded string of the image. Copy this string for use in API requests.

API Endpoints
Synchronous OCR Processing
Endpoint: POST /image-sync

Request Body:

json
{
  "image_data": "<base64_encoded_image>"
}
Response:

json
{
  "text": "Extracted text from image."
}
Asynchronous OCR Processing
Endpoint: POST /image

Request Body:

json
{
  "image_data": "<base64_encoded_image>"
}
Response:

json
{
  "task_id": "<task_id>"
}
Retrieve Task Result:

Endpoint: GET /image/<task_id>

Response:

json
{
  "task_id": "<task_id>",
  "status": "SUCCESS",
  "text": "Extracted text from image."
}

Code Explanation
app.py: Main application file with Flask routes and Celery task configuration.
Dockerfile: Defines the Docker image for the Flask application.
docker-compose.yml: Defines the Docker Compose configuration for Redis, Celery, and the Flask app.
Frontend: Located in templates/index.html and static/ directory.
Testing
Running Tests: Use tools like Postman to test the API endpoints by sending image data in Base64 format.

Running the Project Locally:-
To run the Project_OCR on your local environment, follow these steps:

Activate the Python Virtual Environment: First, activate the virtual environment by sourcing the venv/bin/activate script:
source venv/bin/activate

Install the Project Dependencies: After activating the virtual environment, install the required dependencies using the requirements.txt file:

pip install -r requirements.txt

Run the Redis Server: Start the Redis server, which is required for Celery to function properly:

redis-server

Start the Celery Worker: Run the Celery worker that will handle the background tasks:

celery -A app.celery worker --loglevel=info

Run the Flask Application: Finally, start the Flask application by running the following command:
python app.py